#!/usr/bin/env bash
# Applies every AgriGuard improvement non-interactively.
# Usage (from anywhere):  bash apply.sh [path/to/AgriGuard]   (default: current directory)
# Overwrites the 10 files below with their final versions. Safe to run twice.
# Originals are backed up to <repo>/.agriguard-backup-<timestamp>/
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET="$(cd "${1:-.}" && pwd)"

[ -f "$TARGET/backend/app/main.py" ] || { echo "ERROR: $TARGET is not the AgriGuard repo root (backend/app/main.py not found)"; exit 1; }

BK="$TARGET/.agriguard-backup-$(date +%Y%m%d-%H%M%S)"
cd "$HERE/files"
find . -type f | while read -r f; do
  f="${f#./}"
  if [ -f "$TARGET/$f" ]; then mkdir -p "$BK/$(dirname "$f")"; cp -f "$TARGET/$f" "$BK/$f"; fi
  mkdir -p "$TARGET/$(dirname "$f")"
  cp -f "$HERE/files/$f" "$TARGET/$f"
  echo "  applied: $f"
done
echo
echo "Done. Backup of replaced files: $BK"
echo "Next: cd $TARGET && source .venv/bin/activate && python scripts/train_models.py && python -m pytest -q tests quant/tests"
